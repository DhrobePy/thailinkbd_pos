<?php
echo "<h1>PHP Server Test</h1>";
echo "<p>Server is working correctly!</p>";
echo "<p>Current time: " . date('Y-m-d H:i:s') . "</p>";
?>

