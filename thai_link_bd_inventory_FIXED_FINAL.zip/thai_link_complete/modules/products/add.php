<?php
session_start();
require_once '../../config/config.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    header('Location: ../auth/login.php');
    exit;
}

$currentUser = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Add Product</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="../../index.php" class="text-xl font-bold text-blue-600">Thai Link BD</a>
                    <div class="hidden md:ml-6 md:flex md:space-x-8">
                        <a href="../../index.php" class="text-gray-500 hover:text-gray-700 px-3 py-2 text-sm font-medium">Dashboard</a>
                        <a href="../products/index.php" class="text-blue-600 border-b-2 border-blue-600 px-3 py-2 text-sm font-medium">Products</a>
                        <a href="../inventory/index.php" class="text-gray-500 hover:text-gray-700 px-3 py-2 text-sm font-medium">Inventory</a>
                        <a href="../pos/index.php" class="text-gray-500 hover:text-gray-700 px-3 py-2 text-sm font-medium">POS</a>
                        <a href="../invoices/index.php" class="text-gray-500 hover:text-gray-700 px-3 py-2 text-sm font-medium">Invoices</a>
                        <a href="../reports/index.php" class="text-gray-500 hover:text-gray-700 px-3 py-2 text-sm font-medium">Reports</a>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-700">Welcome, <?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    <a href="../auth/login.php?logout=1" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="md:flex md:items-center md:justify-between mb-6">
            <div class="flex-1 min-w-0">
                <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                    Add New Product
                </h2>
                <p class="mt-1 text-sm text-gray-500">
                    Create a new product in your cosmetics inventory
                </p>
            </div>
            <div class="mt-4 flex md:mt-0 md:ml-4">
                <a href="index.php" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                    <i class="fas fa-arrow-left -ml-1 mr-2 h-4 w-4"></i>
                    Back to Products
                </a>
            </div>
        </div>

        <!-- Success/Error Messages -->
        <div id="messageContainer" class="mb-6 hidden">
            <div id="successMessage" class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg hidden">
                <div class="flex">
                    <i class="fas fa-check-circle text-green-400 mr-3 mt-0.5"></i>
                    <span id="successText"></span>
                </div>
            </div>
            <div id="errorMessage" class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg hidden">
                <div class="flex">
                    <i class="fas fa-exclamation-circle text-red-400 mr-3 mt-0.5"></i>
                    <span id="errorText"></span>
                </div>
            </div>
        </div>

        <!-- Product Form -->
        <div class="bg-white shadow rounded-lg">
            <form id="productForm" class="space-y-6 p-6">
                <!-- Basic Information -->
                <div>
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Basic Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Product Name *</label>
                            <input type="text" id="productName" name="name" required 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="e.g., Lipstick Red Velvet">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">SKU *</label>
                            <input type="text" id="productSku" name="sku" required 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="e.g., LIP001">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Category *</label>
                            <select id="productCategory" name="category" required 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                <option value="">Select Category</option>
                                <option value="makeup">Makeup</option>
                                <option value="skincare">Skincare</option>
                                <option value="haircare">Haircare</option>
                                <option value="fragrance">Fragrance</option>
                                <option value="tools">Beauty Tools</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Brand</label>
                            <input type="text" id="productBrand" name="brand" 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="e.g., Thai Link BD">
                        </div>
                    </div>
                </div>

                <!-- Description -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea id="productDescription" name="description" rows="3" 
                              class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                              placeholder="Detailed product description..."></textarea>
                </div>

                <!-- Pricing -->
                <div>
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Pricing</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Cost Price (৳) *</label>
                            <input type="number" id="costPrice" name="cost_price" step="0.01" min="0" required 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="0.00">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Wholesale Price (৳) *</label>
                            <input type="number" id="wholesalePrice" name="wholesale_price" step="0.01" min="0" required 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="0.00">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Retail Price (৳) *</label>
                            <input type="number" id="retailPrice" name="retail_price" step="0.01" min="0" required 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="0.00">
                        </div>
                    </div>
                </div>

                <!-- Inventory -->
                <div>
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Inventory</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Initial Stock *</label>
                            <input type="number" id="initialStock" name="initial_stock" min="0" required 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="0">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Minimum Stock Level *</label>
                            <input type="number" id="minStock" name="min_stock" min="0" required 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="0">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Unit</label>
                            <select id="productUnit" name="unit" 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                <option value="piece">Piece</option>
                                <option value="bottle">Bottle</option>
                                <option value="tube">Tube</option>
                                <option value="jar">Jar</option>
                                <option value="pack">Pack</option>
                                <option value="set">Set</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Product Variants -->
                <div>
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Product Variants</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Colors</label>
                            <input type="text" id="productColors" name="colors" 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="e.g., Red, Pink, Nude (comma separated)">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Sizes</label>
                            <input type="text" id="productSizes" name="sizes" 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="e.g., 30ml, 50ml, 100ml (comma separated)">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Types</label>
                            <input type="text" id="productTypes" name="types" 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="e.g., Matte, Glossy, Satin (comma separated)">
                        </div>
                    </div>
                </div>

                <!-- Additional Information -->
                <div>
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Additional Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Barcode</label>
                            <div class="mt-1 flex rounded-md shadow-sm">
                                <input type="text" id="productBarcode" name="barcode" 
                                       class="flex-1 block w-full border-gray-300 rounded-l-md focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="Enter or generate barcode">
                                <button type="button" onclick="generateBarcode()" 
                                        class="inline-flex items-center px-3 py-2 border border-l-0 border-gray-300 rounded-r-md bg-gray-50 text-gray-500 text-sm">
                                    Generate
                                </button>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Status</label>
                            <select id="productStatus" name="status" 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="discontinued">Discontinued</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="flex justify-end space-x-3 pt-6 border-t">
                    <a href="index.php" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                        Cancel
                    </a>
                    <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        <i class="fas fa-save mr-2"></i>Save Product
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function generateBarcode() {
            // Generate a random 13-digit barcode
            const barcode = '8' + Math.floor(Math.random() * 1000000000000).toString().padStart(12, '0');
            document.getElementById('productBarcode').value = barcode;
        }

        function showMessage(type, message) {
            const container = document.getElementById('messageContainer');
            const successDiv = document.getElementById('successMessage');
            const errorDiv = document.getElementById('errorMessage');
            
            // Hide all messages first
            successDiv.classList.add('hidden');
            errorDiv.classList.add('hidden');
            
            if (type === 'success') {
                document.getElementById('successText').textContent = message;
                successDiv.classList.remove('hidden');
            } else {
                document.getElementById('errorText').textContent = message;
                errorDiv.classList.remove('hidden');
            }
            
            container.classList.remove('hidden');
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                container.classList.add('hidden');
            }, 5000);
        }

        document.getElementById('productForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const productData = {};
            
            for (let [key, value] of formData.entries()) {
                productData[key] = value;
            }
            
            // Basic validation
            if (!productData.name || !productData.sku || !productData.category || 
                !productData.cost_price || !productData.wholesale_price || !productData.retail_price ||
                !productData.initial_stock || !productData.min_stock) {
                showMessage('error', 'Please fill in all required fields');
                return;
            }
            
            // Validate prices
            if (parseFloat(productData.cost_price) <= 0 || 
                parseFloat(productData.wholesale_price) <= 0 || 
                parseFloat(productData.retail_price) <= 0) {
                showMessage('error', 'All prices must be greater than 0');
                return;
            }
            
            // Validate stock
            if (parseInt(productData.initial_stock) < 0 || parseInt(productData.min_stock) < 0) {
                showMessage('error', 'Stock quantities cannot be negative');
                return;
            }
            
            // Simulate API call
            setTimeout(() => {
                showMessage('success', 'Product "' + productData.name + '" has been created successfully!');
                
                // Reset form after successful submission
                setTimeout(() => {
                    this.reset();
                    // Optionally redirect to products list
                    // window.location.href = 'index.php';
                }, 2000);
            }, 1000);
        });

        // Auto-generate SKU based on product name
        document.getElementById('productName').addEventListener('input', function() {
            const name = this.value;
            if (name && !document.getElementById('productSku').value) {
                // Generate SKU from first 3 letters + random number
                const sku = name.substring(0, 3).toUpperCase() + Math.floor(Math.random() * 1000).toString().padStart(3, '0');
                document.getElementById('productSku').value = sku;
            }
        });

        // Auto-calculate suggested prices
        document.getElementById('costPrice').addEventListener('input', function() {
            const costPrice = parseFloat(this.value) || 0;
            if (costPrice > 0) {
                // Suggest wholesale price (cost + 30%)
                const wholesalePrice = (costPrice * 1.3).toFixed(2);
                if (!document.getElementById('wholesalePrice').value) {
                    document.getElementById('wholesalePrice').value = wholesalePrice;
                }
                
                // Suggest retail price (cost + 60%)
                const retailPrice = (costPrice * 1.6).toFixed(2);
                if (!document.getElementById('retailPrice').value) {
                    document.getElementById('retailPrice').value = retailPrice;
                }
            }
        });
    </script>
</body>
</html>

